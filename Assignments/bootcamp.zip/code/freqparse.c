#include <stdio.h>
int main() {
  // initialize variables;

  char c;

  while ((c = getchar()) != EOF) {
  	// process one character
  }

  // Output results here
  
  return 0;
}
